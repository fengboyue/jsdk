

/// <reference path="../dist/jsdk.d.ts" /> 
JS.config({
    'minimize': false,
    'jsdkRoot': '/jsdk/dist'
})