JS.config({
    'minimize': false,
    'jsdkRoot': '/jsdk/dist'
});
